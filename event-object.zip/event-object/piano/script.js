const piano = document.getElementsByTagName('li'),
  	  pianoPlayers = document.getElementsByTagName('audio');
var	pianoSounds = ['first', 'second', 'third', 'fourth', 'fifth'];


// for (var i = 0; i >= pianoSounds.length - 1; i++) {
	let lst = Array.from(pianoSounds);
	console.log(i);
	console.log(lst);
	console.log(lst[i]);
	pianoPlayers[i].src = lst[i];
// }

playSound = function(event) {
	event.currentTarget.getElementsByTagName('audio')[0].src = 
	
	console.log(event.currentTarget.getElementsByTagName('audio')[0])
	console.log(event.currentTarget)
}


piano[0].addEventListener('click', playSound)
piano[1].addEventListener('click', playSound)
piano[2].addEventListener('click', playSound)
